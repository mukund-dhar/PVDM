#!/bin/bash

# ======== CPU Config ======== 
#SBATCH -n 1
#SBATCH -c 4 
#SBATCH --mem-per-cpu=16G 

# ======== GPU Config ======== 
#SBATCH -p gpu # partition
#SBATCH --gres=gpu:1 
#SBATCH -C '(turing|volta)' 

# ======== Slurm config ======== 
#SBATCH --job-name=cbs

source env/bin/activate

python demo2.py
