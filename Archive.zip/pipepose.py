import mediapipe as mp
import numpy as np
import cv2

COCO = {
    0: 'NOSE',
    1: 'THORAX',
    2: 'RIGHT_SHOULDER',
    3: 'RIGHT_ELBOW',
    4: 'RIGHT_WRIST',
    5: 'LEFT_SHOULDER',
    6: 'LEFT_ELBOW',
    7: 'LEFT_WRIST',
    8: 'RIGHT_HIP',
    9: 'RIGHT_KNEE',
    10: 'RIGHT_ANKLE',
    11: 'LEFT_HIP',
    12: 'LEFT_KNEE',
    13: 'LEFT_ANKLE',
    14: 'RIGHT_EYE',
    15: 'LEFT_EYE',
    16: 'RIGHT_EAR',
    17: 'LEFT_EAR'} 

mp_pose = mp.solutions.pose

# help(mp_pose.Pose)

# Initialize MediaPipe Pose.
pose = mp_pose.Pose(static_image_mode=True, min_detection_confidence=0.5)

# # Prepare DrawingSpec for drawing the face landmarks later.
# mp_drawing = mp.solutions.drawing_utils 
# drawing_spec = mp_drawing.DrawingSpec(thickness=2, circle_radius=2)

def get_coords(image):
    coco_a = COCO.copy()
    coco_a.pop(1) # remove THORAX

    # print(image.shape)
    if image.shape[2] > 3:
        image = np.transpose(image, (1, 2, 0))
    # print(image.shape)
    image_height, image_width, _ = image.shape

    results = pose.process(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))

    if results.pose_landmarks is None:
        return None
    
    COORDS = {}
    all_keypoints = results.pose_landmarks.landmark
    keypoint_names = mp_pose.PoseLandmark

    COORDS["THORAX"] = ((all_keypoints[keypoint_names["RIGHT_SHOULDER"]].x + all_keypoints[keypoint_names["LEFT_SHOULDER"]].x)/2, 
                        (all_keypoints[keypoint_names["RIGHT_SHOULDER"]].y + all_keypoints[keypoint_names["LEFT_SHOULDER"]].y)/2)

    for coco_keypoint in coco_a.values():
        COORDS[coco_keypoint] = (all_keypoints[keypoint_names[coco_keypoint]].x, all_keypoints[keypoint_names[coco_keypoint]].y)

    # keypoints_coords = [all_keypoints[keypoint_names[coco_keypoint]] for coco_keypoint in COCO.values()]
    for key, (x, y) in COORDS.items():
        COORDS[key] = (x * image_width, y * image_height)

    output = []
    for coco_value in COCO.values():
        output.append(COORDS[coco_value])
    return np.array(output)

# image = cv2.imread('photo1.jpg')
# print(get_coords(image))
